import ServiceComponent from "@/components/service-component";

export default function ServicesTypes() {
  return (
    <div className="service-main-container">
      <h1>Services</h1>
      <ServiceComponent />
    </div>
  );
}
