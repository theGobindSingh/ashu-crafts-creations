export default function Landing() {
  return (
    <div id="landing">
      <p className="hero-title">
        Let us capture <i>moments</i> of your life
      </p>
      <div className="hero-brief">
        <h1 className="hero-heading">
          John <br /> Wick
        </h1>
        <h2 className="hero-subject">Ass ass in</h2>
      </div>
    </div>
  );
}
