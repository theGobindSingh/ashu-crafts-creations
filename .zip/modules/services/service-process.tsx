import ProcessComponent from "@/components/process-component";

export default function ServiceProcess() {
  return (
    <div className="process-container">
      <h2>/ Process</h2>
      <ProcessComponent />
    </div>
  );
}
