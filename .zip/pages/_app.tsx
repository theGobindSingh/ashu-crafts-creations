import Header from "@/components/header";
import "@/styles/styles.scss";
import type { AppProps } from "next/app";

export default function App({ Component, pageProps }: AppProps) {
  return (
    <>
      <div id="auth" className="hidden">
        <span>Login</span>
      </div>
      <Header />
      <Component {...pageProps} />
    </>
  );
}
